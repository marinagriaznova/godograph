'''(Е. Джобс) Текстовый файл 24-j5.txt
состоит не более чем из 106 символов S, T, O, C, K.
Сколько раз встречается в файле комбинация «KTO»?
7973'''

f = open('24-j5.txt').readline()
count = 0
for i in range(len(f)-2):
    if f[i] == 'K' and f[i+1] == 'T' and f[i+2] == 'O':
        count += 1
print(count)